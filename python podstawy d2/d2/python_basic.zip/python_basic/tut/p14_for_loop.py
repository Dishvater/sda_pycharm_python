#!/usr/bin/env python
# -*- coding: utf-8 -*-

for index, value in enumerate('Python'):
    print(f'Current value: {value} on index: {index}')
else:
    print('Ended')
