#!/usr/bin/env python
# -*- coding: utf-8 -*-
number = 2
power = 2


def calculate_power(value, exponent):
    result = value ** exponent
    return result


if __name__ == "__main__":
    print(calculate_power(number, power))
    pass
