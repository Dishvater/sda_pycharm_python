#!/usr/bin/env python
# -*- coding: utf-8 -*-

set_a = {1, 2, 3, 4, 5}
set_b = {2, 4, 6, 8, 10}


if __name__ == '__main__':
    print(set_a.symmetric_difference(set_b))
