#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import Counter

data = [1, 2, 3, 3, 3, 1, 4]

if __name__ == '__main__':
    Counter(data)
