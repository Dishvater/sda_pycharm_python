from test.okrag import circle_area

if __name__ == '__main__':
    print(circle_area(3))
